CREATE DATABASE memberdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE memberdb;
-- member 테이블 생성
CREATE TABLE member (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(200) NOT NULL UNIQUE
);
-- 테스트 데이터 삽입 (선택)
INSERT INTO member (name, email) VALUES ('이순신', 'lee@example.com');
INSERT INTO member (name, email) VALUES ('김철수', 'kim@example.com');
INSERT INTO member (name, email) VALUES ('홍창기', 'hong1@example.com');
INSERT INTO member (name, email) VALUES ('박해민', 'park@example.com');
INSERT INTO member (name, email) VALUES ('신민재', 'shin@example.com');
SELECT * FROM member;

grant all privileges on memberdb. * to 'test'@'%';
flush privileges;