-- 사용자 & 권한 관리
-- 사용자 생성 및 권한 부여
-- 사용자 생성
-- === 실습 =================================================================
--           계정명                                 패스워드
-- localhost(현재pc)에서만  접속 가능한 student 계정
-- localhost에서만 점속할 수 있는 student 사용자를 만들고 비미번호를 1234로 설정하시오.
create user 'student'@'localhost' identified by 'pass1234';

-- 모든 ip에서 접속 가능한 student 사용자 생성
create user 'test'@'%' identified by '1234';

-- 모든 ip에서 접속 하는 student사용자에게 shopdb의 모든 권한 부여
grant all privileges on shopdb.* to 'test'@'%';

-- =========================================================================
-- localhost 사용자에게 shopdb 데이터베이스의 모든 권한 부여
-- localhost 에서 접속하는 student사용자에게 shopdb의 모든 권한 부여
-- 특정 db에 모든 권한 부여(all provileges : 조회, 추가, 수정, 삭제, 테이블 생성등...)
grant all privileges on shopdb.* to 'student'@'localhost';
-- 읽기 권한만 부여
grant select on shopdb.* to 'student'@'localhost';
-- 읽기, 추가 권한만 부여
grant select, insert on shopdb.* to 'student'@'localhost';
-- 권한 즉시 적용
flush privileges;
-- 권한 확인
show grants for 'student'@'localhost';
-- 권한 회수
-- revoke all privileges on shopdb.* from 'student'@'localhost';
revoke all privileges, grant option from 'student'@'%';
revoke grant option on shopdb.* from 'student'@'localhost';
-- 사용자 삭제
drop user 'student'@'localhost';

-- 자주 사용하는 내장함수 : concat(), length(), char_length(), upper(), 
--                   lower(), trim(), substring(), replace(),
-- 숫자함수 : round(), ceil(), floor(), abs(), mod()

-- 날짜함수 : now(), curdate(), date_format(), datediff(), date_add()
--         year()month()
-- 조건함수
-- if 문
select name, age, 
	   if (age >= 20, '성인', '미성년자') as 구분
  from customers;
-- case 문
select name, city,
       case city 
			when '서울' then '수도권'
			when '인천' then '수도권'
       else '기타'
	   end as '지역구분'
  from customers;
-- ifnull : null 이면 대체값 반환
select name, ifnull(phone, '번호없음') as '전화번호'
  from customers;

  


