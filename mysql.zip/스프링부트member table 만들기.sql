use memberdb;
select * from member;

alter table member
      add phone varchar(20),
	  add address varchar(200);
      
UPDATE member 
SET phone = '010-1234-5678', 
    address = '서울시 강남구 역삼동 123번지'
WHERE id = 1;

UPDATE member 
SET phone = '010-9988-5678', 
    address = '서울시 천호동 먹자골목'
WHERE id = 2;

UPDATE member 
SET phone = '010-4455-8877', 
    address = '경기도 구리시 덕현'
WHERE id = 3;

UPDATE member 
SET phone = '010-4321-5568', 
    address = '전라남도 광주시 어디어디'
WHERE id = 4;

UPDATE member 
SET phone = '010-5555-9978', 
    address = '재주시 제주도 골목에서'
WHERE id = 5;

update member 
   set name = "김현수", email = 'kim@test.com'
 where id = 1;
 
insert into member (id, name, email, phone, address)
values(5, "구본혁", "gugu@test.com", "010-5689-4578", "강원도 춘천시 어느산골");
