package com.example.jpasecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaSecurityApplicationTests {

    @Test
    void contextLoads() {
    }

}
