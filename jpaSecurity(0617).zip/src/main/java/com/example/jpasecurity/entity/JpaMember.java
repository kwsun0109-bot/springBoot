package com.example.jpasecurity.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import lombok.extern.slf4j.Slf4j;

@Entity
@Slf4j
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JpaMember {

    @Id@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "이름을 입력해주세요")
    @Column(nullable = false, length = 50)
    private String name;

    @Email(message = "올바른 이메일 형식이 아닙니다")
    @NotBlank(message = "이메일을 입력해주세요")
    @Column(nullable = false, unique = true, length = 100)
    private String email;

    @Column(length = 20)
    private String phone;

    @Column(length = 10)
    private String birthdate;

    @Column(nullable = false, unique = true, length = 50)
    private String username;

    @Column(nullable = false)  //암호화되어 저장되어야 함
    private String password;

    @Column(nullable = false, length = 20)
    private String role;

    public void update(String name, String email, String phone, String birthdate) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.birthdate = birthdate;
    }
}
