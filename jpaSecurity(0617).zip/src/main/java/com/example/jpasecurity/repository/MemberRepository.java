package com.example.jpasecurity.repository;

import com.example.jpasecurity.entity.JpaMember;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MemberRepository extends JpaRepository<JpaMember, Long> {
    Page<JpaMember> findByNameContaining(String keyword, Pageable pageable);
    Optional<JpaMember> findByUsername(String username);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
}
