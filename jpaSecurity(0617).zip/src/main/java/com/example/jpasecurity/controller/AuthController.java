package com.example.jpasecurity.controller;

import com.example.jpasecurity.dto.RegisterDto;
import com.example.jpasecurity.service.MemberService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final MemberService memberService;

    // 로그인 화면 — GET /auth/login
    // 로그인 처리(POST)는 Spring Security가 자동으로 처리
    @GetMapping("/login")
    public String loginForm() {
        return "auth/login"; // templates/auth/login.html 반환
    }

    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("registerDto", new RegisterDto());
        return "auth/register";
    }

    @PostMapping("/register")
    public String register (
        @Valid
        @ModelAttribute("registerDto") RegisterDto dto,
        BindingResult result,
        Model model) {

        if (result.hasErrors()) return "auth/register";
        try {
            memberService.register(dto);
            return "redirect:/auth/login?registered=true";
        } catch (IllegalArgumentException e) {
            model.addAttribute("errorMsg", e.getMessage());
            return "auth/register";
        }
    }

}