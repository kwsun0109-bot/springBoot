package com.example.jpasecurity.controller;

import com.example.jpasecurity.entity.JpaMember;
import com.example.jpasecurity.service.UserAccount;
import com.example.jpasecurity.service.MemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.lang.reflect.Member;
import java.util.List;

@Controller
@RequestMapping("/member")
@RequiredArgsConstructor
@Slf4j
public class MemberController {

    private final MemberService memberService;

    // 회원 목록 조회 - GET /member/list
    @GetMapping("/list")
    public String list (@RequestParam(required = false) String keyword, Model model,
                        @PageableDefault(page = 0, size = 5, sort = "id",
                                direction = Sort.Direction.DESC) Pageable pageable) {


        // 2. 서비스를 통해 페이징된 데이터 가져오기
        Page<JpaMember> memberPage = memberService.list(pageable);
        if (keyword != null && !keyword.isBlank()) {
            Page<JpaMember> searchResult = memberService.search(keyword, pageable);
            model.addAttribute("members", searchResult);
            memberPage = Page.empty(pageable);
        } else {
            memberPage = memberService.list(pageable);
            model.addAttribute("members", memberPage.getContent());
        }

        // 3. Thymeleaf 뷰로 전달
        model.addAttribute("memberPage", memberPage);

        int nowPage = memberPage.getPageable().getPageNumber() + 1; // 0부터 시작하므로 화면 표시용 +1
        int startPage = Math.max(1, nowPage - 4);
        int endPage = Math.min(memberPage.getTotalPages() == 0 ? 1 : memberPage.getTotalPages(), nowPage + 4);

        model.addAttribute("nowPage", nowPage);
        model.addAttribute("startPage", startPage);
        model.addAttribute("endPage", endPage);
        model.addAttribute("keyword", keyword);

        return "member/list";
    }
    // 수정화면
    @GetMapping("/edit/{id}")
    public String editForm(
            @PathVariable Long id,
            @AuthenticationPrincipal UserAccount userAccount,
            Model model) {

        System.out.println("id = " + id);
        System.out.println("userAccount = " + userAccount);

        JpaMember target = memberService.findById(id);
        System.out.println("target = " + target);
        // ★ 본인 확인: DB에 저장된 대상 id와 로그인 사용자의 id를 비교
        // 타인이 URL을 직접 입력해도 여기서 차단됩니다
        if (!target.getId().equals(userAccount.getJpaMember().getId())) {
            return "redirect:/member/list?error=forbidden";
        }
        model.addAttribute("member", target);
        return "member/editForm";
    }
    // 수정처리
    @PostMapping("/edit/{id}")
    public String update(
            @PathVariable Long id,
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam(required = false) String phone,
            @RequestParam String birthdate,
            @AuthenticationPrincipal UserAccount userAccount,
            RedirectAttributes redirectAttributes) {
        JpaMember target = memberService.findById(id);

        if (!target.getId().equals(userAccount.getJpaMember().getId())) {
            return "redirect:/member/list?error=forbidden";
        }
        memberService.update(id, name, email, phone, birthdate);
        redirectAttributes.addFlashAttribute("message", "수정이 완료되었습니다.");
        return "redirect:/member/list";
    }
    // 삭제 처리 — GET /member/delete/{id}
    @GetMapping("/delete/{id}")
    public String delete(
            @PathVariable Long id,
            @AuthenticationPrincipal UserAccount userAccount,
            RedirectAttributes redirectAttributes) {
        JpaMember target = memberService.findById(id);
        // ★ 본인 확인 — 타인의 게시글 삭제 시도 차단
        if (!target.getId().equals(userAccount.getJpaMember().getId())) {
            return "redirect:/member/list?error=forbidden";
        }
        memberService.delete(id);
        redirectAttributes.addFlashAttribute("message", "삭제되었습니다.");
        return "redirect:/member/list";
    }
}
