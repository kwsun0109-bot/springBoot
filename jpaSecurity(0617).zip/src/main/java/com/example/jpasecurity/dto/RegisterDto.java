package com.example.jpasecurity.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class RegisterDto {

    @NotBlank(message = "이름을 입력해주세요")
    private String name;

    @Email(message = "올바른 이메일 형식이 아닙니다")
    @NotBlank(message = "이메일을 입력해주세요")
    private String email;

    @Pattern(regexp = "^010-\\d{4}-\\d{4}$",   //^$|^01[0-9]-\\d{3,4}-\\d{4}$
            message = "전화번호 형식이 올바르지 않습니다 (예: 010-1234-5678)")
    private String phone;

    @Pattern(regexp = "^d{4}.\\d{2}.\\d{2}$",
             message = "생년월일 입력해주세요  예:1900.01.01")
    private String birthdate;

    @NotBlank(message = "아이디를 입력해주세요")
    @Size(min = 4, max = 20, message = "아이디는 4~20자 사이여야 합니다")
    @Pattern(regexp = "^[a-zA-Z0-9]+$",
            message = "아이디는 영문, 숫자만 사용 가능합니다")
    private String username;

    @NotBlank(message = "비밀번호를 입력해주세요")
    @Size(min = 4, message = "비밀번호는 4자 이상이어야 합니다")
    private String password;

}