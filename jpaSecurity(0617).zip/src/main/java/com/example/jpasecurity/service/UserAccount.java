package com.example.jpasecurity.service;

import com.example.jpasecurity.entity.JpaMember;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.Collection;
import java.util.List;

public class UserAccount implements UserDetails {

    private final JpaMember jpaMember;
    public UserAccount(JpaMember jpaMember) {
        this.jpaMember = jpaMember;
    }
    public JpaMember getJpaMember() {
        return jpaMember;
    }
    @Override
    public String getUsername() {
        return jpaMember.getUsername();
    }
    @Override
    public String getPassword() {
        return jpaMember.getPassword();
    }
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority(jpaMember.getRole()));
    }
    @Override
    public boolean isAccountNonExpired() {return true;}
    @Override
    public boolean isAccountNonLocked() {return true;}
    @Override
    public boolean isCredentialsNonExpired() {return true;}
    @Override
    public boolean isEnabled() {return true;}
}
